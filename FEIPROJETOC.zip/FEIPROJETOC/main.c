#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <locale.h>
#include <stdbool.h>
#include <time.h>
#include <conio.h>

#define HIST_COTACAO 23

typedef struct {
    double bitcoin;
    double ethereum;
    double ripple;
} Cotacao;

int carregarCotacoes(Cotacao hist[], int *qtd) {
    FILE *arquivo = fopen("cotacao.txt", "r");
    if (arquivo == NULL) {
        return 1;
    }

    Cotacao lidas[256];
    int total = 0;
    char linha[128];
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        Cotacao item;
        if (sscanf(linha, "%lf;%lf;%lf", &item.bitcoin, &item.ethereum, &item.ripple) == 3) {
            if (total < 256) {
                lidas[total++] = item;
            }
        }
    }
    fclose(arquivo);

    if (total == 0) {
        return 1;
    }

    int inicio = 0;
    if (total > HIST_COTACAO) {
        inicio = total - HIST_COTACAO;
    }
    *qtd = total - inicio;
    for (int i = 0; i < *qtd; i++) {
        hist[i] = lidas[inicio + i];
    }
    return 0;
}

int salvarCotacoes(Cotacao hist[], int qtd) {
    FILE *arquivo = fopen("cotacao.txt", "w");
    if (arquivo == NULL) {
        return 1;
    }
    for (int i = 0; i < qtd; i++) {
        fprintf(arquivo, "%.2f;%.2f;%.2f\n", hist[i].bitcoin, hist[i].ethereum, hist[i].ripple);
    }
    fclose(arquivo);
    return 0;
}

int atualizarCotacao(Cotacao hist[], int *qtd) {
    if (*qtd <= 0) {
        return 1;
    }

    Cotacao anterior = hist[*qtd - 1];
    Cotacao nova;
    nova.bitcoin = anterior.bitcoin * (1.0 + (-0.05 + ((rand() / (double)RAND_MAX) * 0.10)));
    nova.ethereum = anterior.ethereum * (1.0 + (-0.05 + ((rand() / (double)RAND_MAX) * 0.10)));
    nova.ripple = anterior.ripple * (1.0 + (-0.05 + ((rand() / (double)RAND_MAX) * 0.10)));

    if (*qtd < HIST_COTACAO) {
        hist[*qtd] = nova;
        (*qtd)++;
    } else {
        for (int i = 1; i < HIST_COTACAO; i++) {
            hist[i - 1] = hist[i];
        }
        hist[HIST_COTACAO - 1] = nova;
    }

    return salvarCotacoes(hist, *qtd);
}

void mostrarCotacoes(Cotacao hist[], int qtd) {
    system("cls");
    printf("ESPACO: atualizar cotacao    qualquer outra tecla: sair\n\n");
    printf("Historico (ate %d precos, o ultimo e o atual)\n\n", HIST_COTACAO);
    printf("%4s %16s %16s %16s\n", "#", "BITCOIN", "ETHEREUM", "RIPPLE");
    for (int i = 0; i < qtd; i++) {
        printf("%4d %16.2f %16.2f %16.2f%s\n", i + 1, hist[i].bitcoin, hist[i].ethereum, hist[i].ripple, (i == qtd - 1) ? "  <- atual" : "");
    }
    printf("\n");
}

int pedirSenha(char usuario[]){
    system("cls");
    bool igual = false;
    char senhainpt[7];
    printf("Digite a senha de 6 digitos:\n");
    scanf("%6s", senhainpt);    
    
    FILE *arquivodados = fopen("usuarios.txt", "r");
    
    char linhaa[50];
    while (fgets(linhaa, sizeof(linhaa), arquivodados) != NULL){
          char *usuarioarq = strtok(linhaa, "/");
          char *senhaarq = strtok(NULL, "\r\n");
          if (strcmp(usuario, usuarioarq) == 0){
             if (strcmp(senhaarq, senhainpt) == 0){
                igual = true;    
             } 
          }
    }
    fclose(arquivodados);
    system("cls");
    return igual;
}

int atualizarSaldo(char usuario[], float valor, int operacao, int tipo){
    FILE *original = fopen("dados.txt", "r");
    if (original == NULL){
       printf("Erro ao abrir dados.txt!\n");
       return 1;           
    }
    FILE *temporario = fopen("temp.txt", "w");
    if (temporario == NULL){
       fclose(original);
       printf("Erro ao criar arquivo tempor�rio!");
       return 1;
    }
    
    int encontrado = 0;
    char linha[200];
    while (fgets(linha, sizeof(linha), original) != NULL){
          char copia[200];
          strcpy(copia, linha);
    
          char *usuarioarq = strtok(copia, ";");
          char *nome = strtok(NULL, ";");
          char *cpf = strtok(NULL, ";");
          char *reais = strtok(NULL, ";");
          char *bitcoin = strtok(NULL, ";");
          char *ethereum = strtok(NULL, ";");
          char *ripple = strtok(NULL, ";");
          if (strcmp(usuario, usuarioarq) == 0){
             float novosaldo;
             if (operacao == 1){
                novosaldo = atof(reais) + valor;
             }else if (operacao == 0){
                if (atof(reais) >= valor){
                   novosaldo = atof(reais) - valor;
                }else{
                printf("N�o � poss�vel fazer essa opera��o!\n\n");
                fclose(temporario);
                fclose(original);
                return 1;      
                }
             }else{
               printf("OPERACAO INVALIDA!\n");
               fclose(temporario);
               fclose(original);
               return 1;
             }
             printf("\nNOVO SALDO: %.2f\n", novosaldo);
             encontrado = 1;
             if (tipo == 0){
               fprintf(temporario, "%s;%s;%s;%.2f;%.2f;%.2f;%.2f\n", usuarioarq, nome, cpf, novosaldo, atof(bitcoin), atof(ethereum), atof(ripple));
             }else if (tipo == 1){
               fprintf(temporario, "%s;%s;%s;%.2f;%.2f;%.2f;%.2f\n", usuarioarq, nome, cpf, atof(reais), novosaldo, atof(ethereum), atof(ripple));      
             }else if (tipo == 2){
               fprintf(temporario, "%s;%s;%s;%.2f;%.2f;%.2f;%.2f\n", usuarioarq, nome, cpf, atof(reais), atof(bitcoin), novosaldo, atof(ripple));     
             }else if (tipo == 3){
               fprintf(temporario, "%s;%s;%s;%.2f;%.2f;%.2f;%.2f\n", usuarioarq, nome, cpf, atof(reais), atof(bitcoin), atof(ethereum), novosaldo);      
             }else{
               printf("TIPO INV�LIDO\n");
               fclose(temporario);
               fclose(original);
               return 1;
             }             
          }else{
          fprintf(temporario, "%s;%s;%s;%.2f;%.2f;%.2f;%.2f\n", usuarioarq, nome, cpf, atof(reais), atof(bitcoin), atof(ethereum), atof(ripple));
          }
    }
    fclose(temporario);
    fclose(original);
    if (!encontrado){
       remove("temp.txt");
       printf("Usu�rio n�o encontrado!\n");
       return 1;                 
    }
    if (remove("dados.txt") != 0) {
        printf("Erro ao remover arquivo original!\nAbortando opera�ao\n");
        return 1;
    }
    if (rename("temp.txt", "dados.txt") != 0) {
        printf("Erro ao renomear arquivo temporario!\n");
        return 1;
    }
    return 0;    
}


int cotacaoAtual(Cotacao *atual) {
    Cotacao hist[HIST_COTACAO];
    int qtd = 0;
    if (carregarCotacoes(hist, &qtd) != 0 || qtd <= 0) {
        return 1;
    }
    *atual = hist[qtd - 1];
    return 0;
}

int taxaCompraPct(int moeda) {
    if (moeda == 1) {
        return 2;
    }
    return 1;
}

int taxaVendaPct(int moeda) {
    if (moeda == 1) {
        return 3;
    }
    if (moeda == 2) {
        return 2;
    }
    return 1;
}

const char *nomeMoeda(int moeda) {
    if (moeda == 1) {
        return "Bitcoin";
    }
    if (moeda == 2) {
        return "Ethereum";
    }
    return "Ripple";
}

const char *siglaMoeda(int moeda) {
    if (moeda == 1) {
        return "BTC";
    }
    if (moeda == 2) {
        return "ETH";
    }
    return "XRP";
}

double precoMoeda(Cotacao atual, int moeda) {
    if (moeda == 1) {
        return atual.bitcoin;
    }
    if (moeda == 2) {
        return atual.ethereum;
    }
    return atual.ripple;
}

void limparEntrada(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

int lerConta(char usuario[], double *reais, double *bitcoin, double *ethereum, double *ripple) {
    FILE *arquivo = fopen("dados.txt", "r");
    if (arquivo == NULL) {
        return 1;
    }

    char linha[256];
    int encontrado = 0;
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        char copia[256];
        strcpy(copia, linha);
        char *usuarioarq = strtok(copia, ";");
        strtok(NULL, ";");
        strtok(NULL, ";");
        char *sreais = strtok(NULL, ";");
        char *sbitcoin = strtok(NULL, ";");
        char *sethereum = strtok(NULL, ";");
        char *sripple = strtok(NULL, ";\r\n");
        if (usuarioarq != NULL && sreais != NULL && sbitcoin != NULL &&
            sethereum != NULL && sripple != NULL && strcmp(usuarioarq, usuario) == 0) {
            *reais = atof(sreais);
            *bitcoin = atof(sbitcoin);
            *ethereum = atof(sethereum);
            *ripple = atof(sripple);
            encontrado = 1;
            break;
        }
    }
    fclose(arquivo);
    return encontrado ? 0 : 1;
}

int lerNomeCpf(char usuario[], char nome[], size_t nomeTam, char cpf[], size_t cpfTam) {
    FILE *arquivo = fopen("dados.txt", "r");
    if (arquivo == NULL) {
        return 1;
    }

    char linha[256];
    int encontrado = 0;
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        char copia[256];
        strcpy(copia, linha);
        char *usuarioarq = strtok(copia, ";");
        char *nomearq = strtok(NULL, ";");
        char *cpfarq = strtok(NULL, ";");
        if (usuarioarq != NULL && nomearq != NULL && cpfarq != NULL &&
            strcmp(usuarioarq, usuario) == 0) {
            strncpy(nome, nomearq, nomeTam - 1);
            nome[nomeTam - 1] = '\0';
            strncpy(cpf, cpfarq, cpfTam - 1);
            cpf[cpfTam - 1] = '\0';
            encontrado = 1;
            break;
        }
    }
    fclose(arquivo);
    return encontrado ? 0 : 1;
}

void formatarNumero(double valor, char destino[], size_t tam) {
    snprintf(destino, tam, "%.4f", valor);
    char *ponto = strchr(destino, '.');
    if (ponto != NULL) {
        char *fim = destino + strlen(destino) - 1;
        while (fim > ponto + 1 && *fim == '0') {
            *fim = '\0';
            fim--;
        }
    }
}

int registrarExtrato(char usuario[], char sinal, double valor, const char ativo[],
                     double cotacao, double taxa,
                     double reais, double bitcoin, double ethereum, double ripple) {
    FILE *arquivo = fopen("extrato.txt", "a");
    if (arquivo == NULL) {
        printf("Erro ao gravar extrato.txt!\n");
        return 1;
    }

    time_t agora = time(NULL);
    struct tm *data = localtime(&agora);
    if (data == NULL) {
        fclose(arquivo);
        printf("Erro ao obter a data!\n");
        return 1;
    }

    char cotacaoTxt[32];
    char bitcoinTxt[32];
    char ethereumTxt[32];
    char rippleTxt[32];
    formatarNumero(cotacao, cotacaoTxt, sizeof(cotacaoTxt));
    formatarNumero(bitcoin, bitcoinTxt, sizeof(bitcoinTxt));
    formatarNumero(ethereum, ethereumTxt, sizeof(ethereumTxt));
    formatarNumero(ripple, rippleTxt, sizeof(rippleTxt));

    fprintf(arquivo,
            "%s;%02d-%02d-%04d %02d:%02d %c %.2f %-4s CT: %s TX: %.2f REAL: %.2f BTC: %s ETH: %s XRP: %s\n",
            usuario,
            data->tm_mday, data->tm_mon + 1, data->tm_year + 1900,
            data->tm_hour, data->tm_min,
            sinal, valor, ativo, cotacaoTxt, taxa, reais,
            bitcoinTxt, ethereumTxt, rippleTxt);
    fclose(arquivo);
    return 0;
}

int gravarNegociacao(char usuario[], double reais, double bitcoin, double ethereum, double ripple) {
    FILE *original = fopen("dados.txt", "r");
    if (original == NULL) {
        printf("Erro ao abrir dados.txt!\n");
        return 1;
    }
    FILE *temporario = fopen("temp.txt", "w");
    if (temporario == NULL) {
        fclose(original);
        printf("Erro ao criar arquivo temporario!\n");
        return 1;
    }

    int encontrado = 0;
    char linha[256];
    while (fgets(linha, sizeof(linha), original) != NULL) {
        char copia[256];
        strcpy(copia, linha);
        char *usuarioarq = strtok(copia, ";");
        char *nome = strtok(NULL, ";");
        char *cpf = strtok(NULL, ";");
        if (usuarioarq != NULL && nome != NULL && cpf != NULL && strcmp(usuarioarq, usuario) == 0) {
            fprintf(temporario, "%s;%s;%s;%.2f;%.8f;%.8f;%.8f\n",
                    usuarioarq, nome, cpf, reais, bitcoin, ethereum, ripple);
            encontrado = 1;
        } else {
            fputs(linha, temporario);
        }
    }
    fclose(temporario);
    fclose(original);

    if (!encontrado) {
        remove("temp.txt");
        printf("Usuario nao encontrado!\n");
        return 1;
    }
    if (remove("dados.txt") != 0) {
        printf("Erro ao remover arquivo original!\n");
        return 1;
    }
    if (rename("temp.txt", "dados.txt") != 0) {
        printf("Erro ao renomear arquivo temporario!\n");
        return 1;
    }
    return 0;
}

double saldoMoeda(int moeda, double bitcoin, double ethereum, double ripple) {
    if (moeda == 1) {
        return bitcoin;
    }
    if (moeda == 2) {
        return ethereum;
    }
    return ripple;
}

int negociarCripto(char usuario[], int vendendo) {
    if (!pedirSenha(usuario)) {
        printf("\nSenha invalida ou incorreta");
        Sleep(1500);
        return 1;
    }

    Cotacao atual;
    if (cotacaoAtual(&atual) != 0) {
        printf("Erro ao ler cotacao.txt!\n");
        system("PAUSE");
        return 1;
    }

    double reais, bitcoin, ethereum, ripple;
    if (lerConta(usuario, &reais, &bitcoin, &ethereum, &ripple) != 0) {
        printf("Erro ao ler o saldo!\n");
        system("PAUSE");
        return 1;
    }

    system("cls");
    if (vendendo) {
        printf("VENDER CRIPTOMOEDAS\n\n");
    } else {
        printf("COMPRAR CRIPTOMOEDAS\n\n");
    }
    printf("Cotacao atual:\n");
    printf("1 - Bitcoin:  R$ %.2f\n", atual.bitcoin);
    printf("2 - Ethereum: R$ %.2f\n", atual.ethereum);
    printf("3 - Ripple:   R$ %.2f\n", atual.ripple);
    printf("0 - Voltar\n\n");
    if (vendendo) {
        printf("Seu saldo:\n");
        printf("Bitcoin:  %.8f\n", bitcoin);
        printf("Ethereum: %.8f\n", ethereum);
        printf("Ripple:   %.8f\n\n", ripple);
    } else {
        printf("Saldo em reais: R$ %.2f\n\n", reais);
    }

    int moeda;
    for (;;) {
        printf("Escolha a moeda: ");
        if (scanf("%d", &moeda) != 1) {
            moeda = -1;
            limparEntrada();
        } else {
            limparEntrada();
        }
        if (moeda >= 0 && moeda <= 3) {
            break;
        }
        printf("Opcao invalida.\n");
    }
    if (moeda == 0) {
        return 0;
    }

    int taxaPct = vendendo ? taxaVendaPct(moeda) : taxaCompraPct(moeda);
    double preco = precoMoeda(atual, moeda);
    double quantidade;
    for (;;) {
        printf("\n%s a R$ %.2f (taxa de %s %d%%)\n",
               nomeMoeda(moeda), preco, vendendo ? "venda" : "compra", taxaPct);
        printf("Quantidade (use ponto para decimais): ");
        if (scanf("%lf", &quantidade) != 1) {
            quantidade = 0;
            limparEntrada();
        } else {
            limparEntrada();
        }
        if (quantidade > 0) {
            break;
        }
        printf("Quantidade invalida.\n");
    }

    double taxa = taxaPct / 100.0;
    double bruto = quantidade * preco;
    if (!vendendo) {
        double custo = bruto * (1.0 + taxa);
        if (reais + 0.0000001 < custo) {
            printf("\nSaldo insuficiente. Custo com taxa: R$ %.2f\n", custo);
            system("PAUSE");
            return 1;
        }
        reais -= custo;
        if (moeda == 1) {
            bitcoin += quantidade;
        } else if (moeda == 2) {
            ethereum += quantidade;
        } else {
            ripple += quantidade;
        }
        if (gravarNegociacao(usuario, reais, bitcoin, ethereum, ripple) != 0) {
            system("PAUSE");
            return 1;
        }
        registrarExtrato(usuario, '+', bruto, siglaMoeda(moeda), preco, taxa,
                         reais, bitcoin, ethereum, ripple);
        printf("\nCompra realizada.\n");
        printf("Total pago (com taxa): R$ %.2f\n", custo);
        printf("Novo saldo em reais: R$ %.2f\n", reais);
        printf("%s: %.8f\n", nomeMoeda(moeda), saldoMoeda(moeda, bitcoin, ethereum, ripple));
    } else {
        double possuido = saldoMoeda(moeda, bitcoin, ethereum, ripple);
        if (possuido + 0.0000001 < quantidade) {
            printf("\nSaldo de %s insuficiente.\n", nomeMoeda(moeda));
            system("PAUSE");
            return 1;
        }
        double credito = bruto * (1.0 - taxa);
        reais += credito;
        if (moeda == 1) {
            bitcoin -= quantidade;
        } else if (moeda == 2) {
            ethereum -= quantidade;
        } else {
            ripple -= quantidade;
        }
        if (bitcoin < 0) {
            bitcoin = 0;
        }
        if (ethereum < 0) {
            ethereum = 0;
        }
        if (ripple < 0) {
            ripple = 0;
        }
        if (gravarNegociacao(usuario, reais, bitcoin, ethereum, ripple) != 0) {
            system("PAUSE");
            return 1;
        }
        registrarExtrato(usuario, '-', bruto, siglaMoeda(moeda), preco, taxa,
                         reais, bitcoin, ethereum, ripple);
        printf("\nVenda realizada.\n");
        printf("Total recebido (com taxa): R$ %.2f\n", credito);
        printf("Novo saldo em reais: R$ %.2f\n", reais);
        printf("%s: %.8f\n", nomeMoeda(moeda), saldoMoeda(moeda, bitcoin, ethereum, ripple));
    }

    system("PAUSE");
    return 0;
}

int updatecot(char usuario[]){
    (void)usuario;

    static bool semeado = false;
    if (!semeado) {
        srand((unsigned)time(NULL));
        semeado = true;
    }

    Cotacao hist[HIST_COTACAO];
    int qtd = 0;
    if (carregarCotacoes(hist, &qtd) != 0) {
        printf("Erro ao ler cotacao.txt!\n");
        system("PAUSE");
        return 1;
    }

    for (;;) {
        mostrarCotacoes(hist, qtd);
        int tecla = _getch();
        if (tecla != ' ') {
            break;
        }
        if (atualizarCotacao(hist, &qtd) != 0) {
            printf("Erro ao atualizar a cotacao!\n");
            system("PAUSE");
            return 1;
        }
    }
    return 0;
}


int sacar(char usuario[]){
    float valor;
    system("cls");
    
    FILE *arquivo = fopen("dados.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        system("PAUSE");
        return 1;
    }    
    
    char linha[100];
    while (fgets(linha, sizeof(linha), arquivo) != NULL){
          linha[strcspn(linha, "\r\n")] = 0;
          char *usuarioarq = strtok(linha, ";");
          char *nome = strtok(NULL, ";");
          char *cpf = strtok(NULL, ";");
          char *reais = strtok(NULL, ";");
          if (strcmp(usuarioarq, usuario) == 0){
             printf("Saldo atual: %s\n\n", reais);                    
          }
    }
    fclose(arquivo);
    
    int resultado;
    do {
        printf("Valor do deposito (use ponto para decimais): ");
        
        
        resultado = scanf("%f", &valor);

        int c;
        while ((c = getchar()) != '\n' && c != EOF);

        if (resultado != 1 || valor <= 0) {
            printf("Valor invalido! Tente novamente.\n");
        }
    } while (resultado != 1 || valor <= 0);
    printf("Valor valido inserido: %.2f\n", valor);
    
    if (atualizarSaldo(usuario, valor, 0, 0) == 0) {
        double reais, bitcoin, ethereum, ripple;
        if (lerConta(usuario, &reais, &bitcoin, &ethereum, &ripple) == 0) {
            registrarExtrato(usuario, '-', valor, "REAL", 0, 0, reais, bitcoin, ethereum, ripple);
        }
    }
    
    system("PAUSE");
    
    return 0;
}


int depositar(char usuario[]){
    float valor;
    system("cls");
    
    FILE *arquivo = fopen("dados.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        system("PAUSE");
        return 1;
    }    
    
    char linha[100];
    while (fgets(linha, sizeof(linha), arquivo) != NULL){
          linha[strcspn(linha, "\r\n")] = 0;
          char *usuarioarq = strtok(linha, ";");
          char *nome = strtok(NULL, ";");
          char *cpf = strtok(NULL, ";");
          char *reais = strtok(NULL, ";");
          if (strcmp(usuarioarq, usuario) == 0){
             printf("Saldo atual: %s\n\n", reais);                    
          }
    }
    fclose(arquivo);
    
    int resultado;
    do {
        printf("Valor do deposito (use ponto para decimais): ");
        resultado = scanf("%f", &valor);

        int c;
        while ((c = getchar()) != '\n' && c != EOF);

        if (resultado != 1 || valor <= 0) {
            printf("Valor invalido! Tente novamente.\n");
        }
    } while (resultado != 1 || valor <= 0);
    printf("Valor valido inserido: %.2f\n", valor);
    
    if (atualizarSaldo(usuario, valor, 1, 0) == 0) {
        double reais, bitcoin, ethereum, ripple;
        if (lerConta(usuario, &reais, &bitcoin, &ethereum, &ripple) == 0) {
            registrarExtrato(usuario, '+', valor, "REAL", 0, 0, reais, bitcoin, ethereum, ripple);
        }
    }
    
    system("PAUSE");
    
    return 0;
}


int consultarExtrato(char usuario[]){
    bool senha = pedirSenha(usuario);
    if (senha != 1){
       printf("\nSenha inv�lida ou incorreta");
       Sleep(1500);
       return 1;
    }

    char nome[80];
    char cpf[40];
    if (lerNomeCpf(usuario, nome, sizeof(nome), cpf, sizeof(cpf)) != 0) {
        printf("Usuario nao encontrado!\n");
        system("PAUSE");
        return 1;
    }

    printf("Nome: %s\n", nome);
    printf("CPF: %s\n\n", cpf);

    FILE *arquivo = fopen("extrato.txt", "r");
    if (arquivo == NULL) {
        printf("Nenhuma movimentacao.\n");
        system("PAUSE");
        return 0;
    }

    char linha[320];
    int achou = 0;
    size_t tam = strlen(usuario);
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        if (strncmp(linha, usuario, tam) == 0 && linha[tam] == ';') {
            printf("%s", linha + tam + 1);
            achou = 1;
        }
    }
    fclose(arquivo);

    if (!achou) {
        printf("Nenhuma movimentacao.\n");
    }
    printf("\n");
    system("PAUSE");
    return 0;
}


int consultarSaldo(char usuario[])
{
    bool senha = pedirSenha(usuario);    
    if (senha != 1){
       printf("\nSenha inv�lida ou incorreta");
       Sleep(1500);
       return 1;     
    }
    
    
    FILE *arquivo = fopen("dados.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        system("PAUSE");
        return 1;
    }

    char linha[200];
    int encontrado = 0;
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        char *usuarioarq = strtok(linha, ";");
        char *nome = strtok(NULL, ";");
        char *cpf = strtok(NULL, ";");
        char *reais = strtok(NULL, ";");
        char *bitcoin = strtok(NULL, ";");
        char *ethereum = strtok(NULL, ";");
        char *ripple = strtok(NULL, ";\r\n");

        if (usuarioarq != NULL && strcmp(usuarioarq, usuario) == 0) {
            if (nome == NULL || cpf == NULL ||
                reais == NULL || bitcoin == NULL ||
                ethereum == NULL || ripple == NULL) {
                printf("Dados incompletos no arquivo!\n");
                break;
            }
            printf("Nome: %s\n", nome);
            printf("CPF: %s\n", cpf);
            printf("Reais: %s\n\n", reais);
            printf("Bitcoin: %s\n", bitcoin);
            printf("Ethereum: %s\n", ethereum);
            printf("Ripple: %s\n\n", ripple);
            encontrado = 1;
            break;
        }
    }

    fclose(arquivo);
    system("PAUSE");
    return 0;
}




int menu(char usuario[])
{
    int comando;
    do
    {
        system("cls");
        printf("Ol�, %s!\n\n", usuario);
        printf("1 - Consultar saldo\n");
        printf("2 - Consultar extrato\n");
        printf("3 - Depositar\n");
        printf("4 - Sacar\n");
        printf("5 - Comprar criptomoedas\n");
        printf("6 - Vender criptomoedas\n");
        printf("7 - Atualizar cota��o\n");
        printf("8 - Sair\n\n");
        if (scanf("%d", &comando) != 1) {
            comando = 0;
            int c;
            while ((c = getchar()) != '\n' && c != EOF);
        }
        if (comando == 1)
        {
           consultarSaldo(usuario);
        }else if (comando == 2)
        {
           consultarExtrato(usuario);      
        }else if (comando == 3)
        {
           depositar(usuario);      
        }else if (comando == 4)
        {
           sacar(usuario);      
        }else if (comando == 5)
        {
           negociarCripto(usuario, 0);      
        }else if (comando == 6)
        {
           negociarCripto(usuario, 1);      
        }else if (comando == 7)
        {
           updatecot(usuario);      
        }else if (comando != 8){
           printf("Opcao invalida!\n");
           system("PAUSE");
        }
        
    } while (comando != 8); 
     
 return 0;
}


int main()
{
    ///////////////////
    setlocale(LC_ALL, "Portuguese");
    system("cls");
    bool logado = false;
    char usuariolog[20];
    char inputusuario[20];
    char inputsenha[7];
    printf("Seja bem vindo(a)! Digite seu nome de usu�rio para entrar:\n");
    scanf("%19s", inputusuario);
    printf("Senha: ");
    scanf("%6s", inputsenha);
    
    FILE *arquivo;
    arquivo = fopen("usuarios.txt", "r");
    if (arquivo == NULL){
       printf("Erro ao abrir o arquivo!");
       return 1;
    }
    
    char nome[100];
    while (fgets(nome, sizeof(nome), arquivo) != NULL)
    {
          char *usuario = strtok(nome, "/\n");
          char *senha = strtok(NULL, "/\n\r");
          if ((strcmp(usuario, inputusuario) == 0) && (strcmp(senha, inputsenha) == 0))
          {
             strcpy(usuariolog, inputusuario);
             logado = true;
             break;          
          }
    }
    if (logado)
    {
       menu(usuariolog);
    }
    else{
         printf("Usu�rio ou senha est�o errados!\n");
         Sleep(1500);
         main();
    }

    fclose(arquivo);
	
    return 0;
}
